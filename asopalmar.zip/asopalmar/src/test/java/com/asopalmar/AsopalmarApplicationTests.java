package com.asopalmar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsopalmarApplicationTests {

	@Test
	void contextLoads() {
	}

}
