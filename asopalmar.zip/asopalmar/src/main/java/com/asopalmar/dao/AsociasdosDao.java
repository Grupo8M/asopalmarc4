package com.asopalmar.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asopalmar.model.Asociados;

public  interface AsociasdosDao extends JpaRepository<Asociados, Integer> {
	

}
