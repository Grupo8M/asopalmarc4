package com.asopalmar.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asopalmar.model.Usuarios;

public interface UsuariosDao extends JpaRepository<Usuarios, Integer>{

}
